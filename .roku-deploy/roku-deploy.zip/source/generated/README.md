# Generated BrightScript code

Files in this directory are produced by protoc-gen-brs.

## Proto inputs
- proto/simple.proto

## Supported messages
- SimpleMessage
- CountMessage
- FlagMessage
- FloatMessage
- BytesMessage
- LongMessage
- UnsignedCountMessage
- UnsignedLongMessage
- SignedCountMessage
- SignedLongMessage
- PackedInt32Message
- PackedUint32Message
- PackedSint32Message
- PackedInt64Message
- PackedUint64Message
- PackedSint64Message
- PackedBoolMessage
- PackedFloatMessage

Regenerate with:

```bash
npm run generate:brs -- --proto proto
```
