# Generated BrightScript code

Files in this directory are produced by protoc-gen-brs.

## Proto inputs
- proto/simple.proto

## Supported messages
- SimpleMessage
- CountMessage
- FlagMessage
- BytesMessage
- LongMessage
- UnsignedCountMessage
- UnsignedLongMessage
- SignedCountMessage
- SignedLongMessage

Regenerate with:

```bash
npm run generate:brs -- --proto proto
```
